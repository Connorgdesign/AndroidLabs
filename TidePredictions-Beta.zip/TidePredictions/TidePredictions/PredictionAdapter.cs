﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;

namespace TidePredictions
{
    class PredictionAdapter : SimpleAdapter
    {
        List<IDictionary<string, object>> List;
        Dictionary<string, int> partOfSpeechIndex;

        public PredictionAdapter(Context context,
        List<IDictionary<string, object>> data,
        Int32 resource, String[] from,
        Int32[] to) : base(context, data, resource, from, to)
        {
            List = data;
        }
    }
}