﻿using System;

namespace TidePredictionLibrary
{
    public class Class1
    {
    }
}
